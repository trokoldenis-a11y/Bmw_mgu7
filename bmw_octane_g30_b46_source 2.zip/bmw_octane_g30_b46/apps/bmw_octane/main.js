'use strict';

/**
 * BMW Octane — diagnostic bring-up entry point.
 * This first pass verifies the read-only transport and engine ECU discovery.
 * No guessed RON value or unverified HMI component is displayed.
 */
const mgu = require('./kit/mgu');
const { ReadOnlyDiag } = require('./kit/readonly-diag');
const { PROFILE } = require('./octane');

mgu.run({
    async start(ctx) {
        const { log } = ctx;
        const diag = new ReadOnlyDiag(ctx.signals, log);
        try {
            await diag.init();
            if (!diag.ready) throw new Error(diag.error || 'Diagnostic link unavailable');
            const units = await diag.discover({ idleMs: 2500, maxMs: 12000 });
            const dmeIndex = units.get(PROFILE.expectedDmeAddress) || null;
            if (dmeIndex) {
                log.info('BMW Octane: DME at 0x12 discovered; SGBD index=' + dmeIndex +
                    '. Confirm this is the expected B46 variant before decoding DIDs.');
            } else {
                log.warn('BMW Octane: expected DME address 0x12 was not confirmed. RON estimate disabled.');
            }
        } catch (e) {
            log.warn('BMW Octane diagnostic bring-up failed: ' + String(e.message || e));
        }
    }
});
