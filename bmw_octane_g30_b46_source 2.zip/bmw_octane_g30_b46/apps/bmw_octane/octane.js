'use strict';

/**
 * BMW Octane core — G30 LCI B46 / MGU.
 *
 * This module deliberately does not decode BMW DID payloads itself. It delegates DID
 * decoding to the repository's existing SGBD catalog/decoder so byte lengths, signedness
 * and scaling are not guessed here.
 */

const PROFILE = Object.freeze({
    id: 'g30_lci_b46',
    label: 'BMW G30 LCI 520i B46 (2021)',
    engine: 'B46',
    expectedDmeAddress: 0x12, // conventional engine ECU address in this kit; verify by discovery
    candidateDids: Object.freeze({
        adaptedFuelQuality: 0x5776,
        ignitionAngle: 0x59FA,
        knockDetected: 0x4A36,
        knockRetardMean: 0x554C,
        knockAdaptation: 0x554A,
        fuelInTank: 0x583B,
        timeSinceRefuelling: 0x57E3
    }),
    cylinderIgnitionDids: Object.freeze([0x4A49, 0x4A4A, 0x4A4C, 0x4A4D, 0x4A4E, 0x4A4F])
});

const HISTORY_LIMIT = 5;
const MIN_CONFIDENCE_SAMPLES = 12;
const finite = (v) => typeof v === 'number' && Number.isFinite(v);

function parseDidResponse(uds, requestedDids) {
    // UDS 0x62 response: 62 DID_H DID_L DATA ... . Payload boundaries must come
    // from the SGBD catalog; this parser only preserves the raw DID segments when
    // the caller supplies known byte lengths.
    if (!uds || uds[0] !== 0x62 || !Array.isArray(requestedDids)) return null;
    return { raw: uds.slice(), requestedDids: requestedDids.slice() };
}

async function readCandidateSnapshot(link, decodeDid, address = PROFILE.expectedDmeAddress) {
    if (!link || typeof link.readMany !== 'function') throw new Error('ReadOnlyDiag is unavailable');
    if (typeof decodeDid !== 'function') throw new Error('SGBD DID decoder is required');

    const dids = [
        PROFILE.candidateDids.adaptedFuelQuality,
        PROFILE.candidateDids.ignitionAngle,
        PROFILE.candidateDids.knockDetected,
        PROFILE.candidateDids.knockRetardMean,
        PROFILE.candidateDids.knockAdaptation
    ];
    const cylinderDids = PROFILE.cylinderIgnitionDids;
    const requested = dids.concat(cylinderDids);
    const uds = await link.readMany(address, requested.slice(0, 8));
    const uds2 = await link.readMany(address, requested.slice(8));

    const decodeResponse = (reply, ids) => {
        if (!reply || reply[0] !== 0x62) return {};
        const out = {};
        for (const id of ids) {
            try {
                const value = decodeDid(reply, id);
                if (value !== undefined && value !== null) out[id.toString(16).toUpperCase()] = value;
            } catch (_) { /* A missing/unsupported DID remains unavailable. */ }
        }
        return out;
    };

    return {
        address,
        timestamp: Date.now(),
        first: decodeResponse(uds, requested.slice(0, 8)),
        second: decodeResponse(uds2, requested.slice(8)),
        replies: { first: !!uds, second: !!uds2 }
    };
}

function numericValue(x) {
    if (finite(x)) return x;
    if (x && finite(x.value)) return x.value;
    if (x && finite(x.n)) return x.n;
    return null;
}

function assessFuelQuality(snapshot, state) {
    const raw = snapshot && snapshot.first && snapshot.first['5776'];
    const adapted = numericValue(raw);
    const knockRetard = numericValue(snapshot && snapshot.first && snapshot.first['554C']);
    const knockAdaptation = numericValue(snapshot && snapshot.first && snapshot.first['554A']);
    const knockDetected = snapshot && snapshot.first && snapshot.first['4A36'];

    const validated = !!(state && state.did5776Validated && state.scalingValidated);
    const samples = state && finite(state.validSamples) ? state.validSamples : 0;

    if (!validated || adapted === null || samples < MIN_CONFIDENCE_SAMPLES) {
        return {
            status: 'insufficient_data',
            label: 'Недостаточно данных',
            ronEquivalent: null,
            range: null,
            confidence: 0,
            reason: !validated
                ? 'DID 5776 и его масштабирование ещё не подтверждены на этом автомобиле'
                : 'Недостаточно стабильных наблюдений после заправки',
            diagnostics: { knockRetard, knockAdaptation, knockDetected }
        };
    }

    // DID 5776 is the DME-adapted fuel-quality signal. It is shown only after
    // vehicle-specific validation; it is not a laboratory measurement of gasoline.
    const ron = adapted;
    if (!finite(ron) || ron < 70 || ron > 110) {
        return {
            status: 'invalid_value',
            label: 'Недостаточно данных',
            ronEquivalent: null,
            range: null,
            confidence: 0,
            reason: 'DME вернул значение вне допустимого контрольного диапазона',
            diagnostics: { knockRetard, knockAdaptation, knockDetected }
        };
    }

    const confidence = Math.min(95, 55 + Math.floor(samples / 2));
    const spread = confidence >= 85 ? 1 : 2;
    return {
        status: 'estimated',
        label: 'Расчётный эквивалент RON',
        ronEquivalent: ron,
        range: [Math.max(70, ron - spread), Math.min(110, ron + spread)],
        confidence,
        reason: 'Оценка по адаптированному параметру DME; не лабораторное измерение',
        diagnostics: { knockRetard, knockAdaptation, knockDetected }
    };
}

class RefuelHistory {
    constructor(saved) {
        this.items = Array.isArray(saved) ? saved.filter(RefuelHistory.valid).slice(0, HISTORY_LIMIT) : [];
        this.previousTankLitres = null;
        this.previousRefuelHours = null;
    }

    static valid(x) {
        return !!x && /^\d{4}-\d{2}-\d{2}$/.test(x.date) &&
            finite(x.litres) && x.litres > 0 && finite(x.odometerKm) && x.odometerKm >= 0;
    }

    add({ date, odometerKm, litres, ronRange, confidence, source = 'manual' }) {
        const entry = {
            date, odometerKm, litres,
            ronRange: Array.isArray(ronRange) ? ronRange.slice(0, 2) : null,
            confidence: finite(confidence) ? Math.max(0, Math.min(100, confidence)) : 0,
            source
        };
        if (!RefuelHistory.valid(entry)) throw new Error('Некорректные данные заправки');
        this.items.unshift(entry);
        this.items = this.items.slice(0, HISTORY_LIMIT);
        return entry;
    }

    observeTank({ date, odometerKm, tankLitres, timeSinceRefuellingHours, ronRange, confidence }) {
        if (!finite(tankLitres) || tankLitres < 0) return null;
        const prev = this.previousTankLitres;
        this.previousTankLitres = tankLitres;
        if (finite(timeSinceRefuellingHours)) this.previousRefuelHours = timeSinceRefuellingHours;

        // Conservative event trigger: tank increase >= 5 L. The time-since-refuel
        // counter may reset at the event, so it is recorded but not used as a gate.
        // Volume is an estimate from tank-level delta, not a pump-meter reading.
        if (finite(prev) && tankLitres - prev >= 5) {
            return this.add({
                date, odometerKm, litres: tankLitres - prev,
                ronRange, confidence, source: 'detected_from_tank_delta'
            });
        }
        return null;
    }

    toJSON() { return this.items.slice(0, HISTORY_LIMIT); }
}

module.exports = {
    PROFILE,
    HISTORY_LIMIT,
    MIN_CONFIDENCE_SAMPLES,
    parseDidResponse,
    readCandidateSnapshot,
    assessFuelQuality,
    RefuelHistory
};
